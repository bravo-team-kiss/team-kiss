const express = require('express');
const app = express();
const port = 3000;
const {InfluxDB, Point} = require('@influxdata/influxdb-client');
const path = require('path');

const token = 'RfUEWB9Ww_7JaVZ_DYvYo3VPlTBqwQ8I_fpNDcRAn4GAeY-sbrLHOzVrBEKn8P4sQMT-83sObGudnAAriItlug=='
const org = 'test'
const bucket = 'test'
const client = new InfluxDB({url:'http://localhost:8086', token: token})
const writeApi = client.getWriteApi(org, bucket)
const queryApi = client.getQueryApi(org)

function createPoint(measurement, tags, time, fields) {
  for (i in fields){
    point = new Point(measurement)
    console.log(i)
    for (t in tags){
      point.tag(t, String(tags[t]))
      console.log(t)
      console.log(tags[t])
    }
    point.floatField(i, fields[i])
    console.log(fields[i])

    writeApi.writePoint(point)
    writeApi.close().then(() => {
      console.log('Wrote point')
    }).catch(e => {
      console.error(e)
      console.log('Encountered error')
      console.log(e)
    })
  }
}

function queryPoints(){
  const query = `from(bucket: ${bucket})`
}

/*
const query = `from(bucket: ${bucket}) |> range(start: -1m)`
queryApi.queryRows(query, {
  next(row, tableMeta) {
    const o = tableMeta.toObject(row)
    console.log(o)
    //console.log(`${o._time} ${o._measurement} on : ${o._field}=${o._value}`)
  },
  error(error) {
    console.error(error)
    console.log('Finished ERROR')
  },
  complete() {
    console.log('Finished SUCCESS')
  },
})
*/

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname+'/sendata.html'));
});

app.post('/requestdata', (req, res) => {
  const from_date = req.query.from;
  const to_date = req.query.to;

  res.send({
    'from date': from_date,
    'to date': to_date,
  });
});

app.get('/sendata', (req, res) => {
  const measurement = req.query.measurement;
  const tag1 = req.query.tag1;
  const tag2 = req.query.tag2;
  const time = req.query.time;
  const attr = req.query.attr;
  const value = req.query.value;

  console.log(req.params['tag1'])

  const tags = {
    tag1 : tag2
  }

  const fields = {
    attr : value
  }

  res.send({
    measurement,
    tag1,
    tag2,
    time,
    attr,
    value,
    tags,
    fields
  })
  /*
  if(!createPoint(measurement, tags, Date.now(), fields))
  {
    res.send('<h1>Data push failed</h1>');
    res.status(400);
  }
  res.send('<h2>Sent info to database</h2>');
  */
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

/* Data that will most likely be found in sets

Organization
- By Sensor


Order By
- Latitude
- Longitude
- Time
- Date
-Type

1 bucket, measurement = type of sensor, field = attr of sensor

*/